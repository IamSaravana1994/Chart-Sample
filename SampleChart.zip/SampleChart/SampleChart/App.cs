﻿using Xamarin.Forms;

namespace SampleChart
{
    public class App : Application
    {
        public App()
        {
            MainPage = new Chart();
        }
    }
}
